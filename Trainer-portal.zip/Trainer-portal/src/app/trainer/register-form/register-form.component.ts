import { Component, OnInit } from '@angular/core';
import { Validators } from "@angular/forms";
import { FormGroup } from "@angular/forms";
import { FormBuilder } from "@angular/forms";
import { symbolValidator, passwordMatch } from "src/app/helpers/validations";

@Component({
  selector: 'app-register-form',
  templateUrl: './register-form.component.html',
  styleUrls: ['./register-form.component.css']
})
export class RegisterFormComponent implements OnInit {
registerForm: FormGroup;
  constructor(private builder: FormBuilder) { }
  ngOnInit() {
  
    this.buildForm();
  }
  buildForm(){
    this.registerForm=this.builder.group({
      name: ['', Validators.required],
      email: ['', Validators.compose([Validators.required, Validators.email])],
      password: ['', Validators.compose([Validators.required, symbolValidator])],
      confirmPassword: ''
    },{
      validator: passwordMatch
    });
  }
}

