import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginFormComponent } from "src/app/trainer/login-form/login-form.component";
import { RegisterFormComponent } from "src/app/trainer/register-form/register-form.component";
import { DetailsComponent } from "src/app/trainer/details/details.component";

const routes: Routes = [
  {
    path:'login', component:LoginFormComponent
  },
  {
    path:'register', component:RegisterFormComponent
  },
  {
    path:'details', component:DetailsComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
