import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterFormComponent } from './trainer/register-form/register-form.component';
import { LoginFormComponent } from './trainer/login-form/login-form.component';
import { NavbarComponent } from './trainer/shared/navbar/navbar.component';
import { HeaderComponent } from './trainer/shared/header/header.component';
import { FooterComponent } from './trainer/shared/footer/footer.component';
import { HomeComponent } from './trainer/home/home.component';
import { DetailsComponent } from './trainer/details/details.component';

@NgModule({
  declarations: [
    AppComponent,
    RegisterFormComponent,
    LoginFormComponent,
    NavbarComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    DetailsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    
    ReactiveFormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
